/*
Imagenes

https://es.web.img3.acsta.net/pictures/14/03/17/10/20/509771.jpg
https://upload.wikimedia.org/wikipedia/en/c/cc/A_Bug%27s_Life.jpg
https://upload.wikimedia.org/wikipedia/en/c/c0/Toy_Story_2.jpg
*/

const listaImagenes = [];

const contenedor = document.querySelector("#contenedor");

const nodoImg = document.querySelectorAll(".item img");

nodoImg.forEach((item) => {
  listaImagenes.push(prompt("Subí tu imagen"));
});

nodoImg.forEach((item, index) => {
  item.setAttribute("src", listaImagenes[index]);
});
