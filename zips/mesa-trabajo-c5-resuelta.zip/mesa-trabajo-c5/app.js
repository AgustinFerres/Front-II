function darkMode() {
    let body = document.body;
    let boton = document.querySelector('button')

    body.classList.toggle('dark')

    if(boton.textContent == '🌙'){
        boton.textContent = '💡';
    }else {
        boton.textContent = '🌙';
    }
}   