function darkMode () {
    let body = document.querySelector('body');

    let header = document.querySelector('h1');

    let contenido = document.querySelector('.contenido');

    let links = document.querySelectorAll('.contenido ul li a')

    let main = document.querySelectorAll('section article');


    body.classList.toggle('dark-Body');

    header.classList.toggle('dark-Header');

    contenido.classList.toggle('dark-Contenido');

    links.forEach(nodo => {
        nodo.classList.toggle('dark-Links');
    })

    main.forEach(nodo => {
        
        if (nodo.classList.contains('diferente')) {
            nodo.classList.toggle('dark-Diferente')
        }else {
            nodo.classList.toggle('dark-Article');
        }
    })
}